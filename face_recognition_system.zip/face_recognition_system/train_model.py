import cv2
import numpy as np
from PIL import Image
import os

recognizer = cv2.face.LBPHFaceRecognizer_create()

path = 'dataset'

faceSamples = []
ids = []

for root, dirs, files in os.walk(path):

    for file in files:

        if file.endswith("jpg"):

            imagePath = os.path.join(root, file)

            PIL_img = Image.open(imagePath).convert('L')

            img_numpy = np.array(PIL_img, 'uint8')

            id = int(root.split(".")[-1])

            faces = [img_numpy]

            for face in faces:

                faceSamples.append(face)
                ids.append(id)

recognizer.train(faceSamples, np.array(ids))

if not os.path.exists("trainer"):
    os.makedirs("trainer")

recognizer.write('trainer/trainer.yml')

print("Training Completed")